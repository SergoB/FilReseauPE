package package1;

public class LigneArticle {

	private int quantite;
	private TypeArticle t;
	
	public LigneArticle(int quantite, TypeArticle t) 
	{
		this.quantite = quantite;
		this.t = t;
	}
	
	

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + quantite;
		result = prime * result + ((t == null) ? 0 : t.hashCode());
		return result;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LigneArticle other = (LigneArticle) obj;
		if (quantite != other.quantite)
			return false;
		if (t == null) {
			if (other.t != null)
				return false;
		} else if (!t.equals(other.t))
			return false;
		return true;
	}


	/**
	 * @return the quantite
	 */
	public int getQuantite() {
		return quantite;
	}



	/**
	 * @param quantite the quantite to set
	 */
	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}



	public int getCodeTypeArticle() 
	{
		return t.getCodeArticle();
	}
	
	
	public double getMontantLigne(){
		return t.getPrix()*quantite;
	}
	
	
	
	
}
