package package1;

import java.util.List;
import java.util.ArrayList;


public class Panier {

	private double total;
	private List<LigneArticle> listeLignesArticle = new ArrayList <LigneArticle> ();

	/**
	 * @param total
	 */
	public Panier() {
		this.total = 0.0;
	}


	public void calculerTotal(){	

		this.total = 0.0;

		for (LigneArticle ligne : listeLignesArticle) {

			total += ligne.getMontantLigne();

		}

	}


	/**
	 * @return the listeLignesActricle
	 */
	public List<LigneArticle> getListeLignesArticle() {
		return listeLignesArticle;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(total);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Panier other = (Panier) obj;
		if (Double.doubleToLongBits(total) != Double
				.doubleToLongBits(other.total))
			return false;
		return true;
	}


	/**
	 * @return the total
	 */
	public double getTotal() {
		return total;
	}


	public void ajouterLigne(TypeArticle t1, int quantite) {

		LigneArticle ligne = new LigneArticle (quantite,t1);
		LigneArticle ligneListe = rechercherLigne(t1);
		
		if (nbLignes()==0){
			
			listeLignesArticle.add(ligne);
			
		}else{
			
			if (ligneListe == null){
				listeLignesArticle.add(ligne);
			}else
			{
				ligneListe.setQuantite(ligneListe.getQuantite()+quantite);
			}

		}
	}

	public int nbLignes() {

		return listeLignesArticle.size();

	}


	public LigneArticle rechercherLigne(TypeArticle t1) {

		for (LigneArticle ligne : listeLignesArticle) {

			if (t1.getCodeArticle() == ligne.getCodeTypeArticle()){
				return ligne;
			}

		}
		return null;
	}


}





















