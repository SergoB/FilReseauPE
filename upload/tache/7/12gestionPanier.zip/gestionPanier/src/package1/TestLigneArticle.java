/**
 * 
 */
package package1;

import junit.framework.TestCase;

/**
 * @author o2142062
 *
 */
public class TestLigneArticle extends TestCase {
	
	LigneArticle l;
	TypeArticle t = new TypeArticle (1,"guitare",70.0);
	
	
	
	

	/**
	 * @param name
	 */
	public TestLigneArticle(String name) {
		super(name);
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		l = new LigneArticle(2,t);
	}

	public void testGetMontantLigne(){
		
		assertEquals(140.0, l.getMontantLigne());
		
	}
	
	
}
