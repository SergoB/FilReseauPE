/**
 * 
 */
package package1;

import junit.framework.TestCase;

/**
 * @author o2142062
 *
 */
public class TestPanier extends TestCase {

	Panier p;
	TypeArticle t1 = new TypeArticle(1,"guitare",70.0);
	TypeArticle t2 = new TypeArticle(2,"violon",500.0);
	
	
	/**
	 * @param name
	 */
	public TestPanier(String name) {
		super(name);
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		p = new Panier();
	}
	
	public void testAjouterLigne(){
		
		p.ajouterLigne(t1,1);
		assertEquals(1, p.nbLignes());
		LigneArticle l1 = p.rechercherLigne(t1);
		assertEquals(new LigneArticle (1,t1), l1);
		
		p.ajouterLigne(t2,2);
		assertEquals(2, p.nbLignes());
		
		p.ajouterLigne(t1, 2);
		assertEquals(2, p.nbLignes());
		l1 = p.rechercherLigne(t1);
		assertEquals(3,l1.getQuantite());
		
	}
	
	public void testCalculerTotal(){
		
		p.ajouterLigne(t1, 2);
		LigneArticle l1 = new LigneArticle(2,t1);
		p.calculerTotal();
		assertEquals(l1.getMontantLigne(),p.getTotal());
		p.ajouterLigne(t2, 1);
		LigneArticle l2 = new LigneArticle(1,t2);
		p.calculerTotal();
		assertEquals(l1.getMontantLigne()+l2.getMontantLigne(),p.getTotal());
		
	}

}



























