package package1;

public class TypeArticle {

	private int codeArticle;
	private String libelle;
	private double prix;
		
	public TypeArticle(int codeArticle, String libelle, double prix) {
		
		this.codeArticle = codeArticle;
		this.libelle = libelle;
		this.prix = prix;
		
	}


	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + codeArticle;
		result = prime * result + ((libelle == null) ? 0 : libelle.hashCode());
		long temp;
		temp = Double.doubleToLongBits(prix);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TypeArticle other = (TypeArticle) obj;
		if (codeArticle != other.codeArticle)
			return false;
		if (libelle == null) {
			if (other.libelle != null)
				return false;
		} else if (!libelle.equals(other.libelle))
			return false;
		if (Double.doubleToLongBits(prix) != Double
				.doubleToLongBits(other.prix))
			return false;
		return true;
	}
	
	
	public int getCodeArticle() {
		return codeArticle;
	}
	public void setCodeArticle(int codeArticle) {
		this.codeArticle = codeArticle;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public double getPrix() {
		return prix;
	}
	public void setPrix(double prix) {
		this.prix = prix;
	}
	
	
	
	
	
	
	
	
}
