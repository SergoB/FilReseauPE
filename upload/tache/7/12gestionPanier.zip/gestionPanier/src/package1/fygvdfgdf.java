package package1;

import java.util.Scanner;

public class fygvdfgdf {
	
	public static void main (String []args){
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Saisissez un nombre");
		
		int a = sc.nextInt();
		
		System.out.println("Saisissez son diviseur");
		
		int b = sc.nextInt();
		
		System.out.println("Resultat de la division entiee de "+a+" par "+b+" : "+a/b);
		
		
	}

}
